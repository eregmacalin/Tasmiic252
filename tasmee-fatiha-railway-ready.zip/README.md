# Tasmee' — Faatixa Strict / Railway

## Architecture

- GitHub: source code.
- GitHub Pages: optional static frontend hosting.
- Railway: Python/FastAPI AI backend.
- Quran-specific analysis: `quran-muaalem` + `quran-transcript`.

GitHub Pages cannot run Python/server-side code, so the AI must run on Railway. citeturn0search7

## Option A — easiest: host BOTH frontend and backend on Railway

Upload this repository to GitHub, then create a Railway service from the repository.

Railway will detect `requirements.txt` and run the Python service if a start command is supplied.

Start command:

```bash
uvicorn server:app --host 0.0.0.0 --port $PORT
```

Then open the Railway URL. The frontend and `/analyze` API are on the same domain, so no API URL configuration is needed.

## Option B — GitHub Pages frontend + Railway backend

1. Deploy the backend to Railway.
2. Copy the Railway public URL.
3. Open the GitHub Pages site in the browser console once and set:

```js
localStorage.setItem("TASMEE_API_URL", "https://YOUR-RAILWAY-DOMAIN")
location.reload()
```

A future version should replace this with a visible Settings/API configuration field.

GitHub Pages is for static HTML/CSS/JS and does not run Python server-side code. citeturn0search0turn0search7

## Railway notes

The AI model is much heavier than the HTML frontend. First deploy it as a single Railway service and test Faatixa. If memory/CPU becomes a problem, split frontend and backend or move inference to a suitable GPU service later.

## Local run

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
```

Open:

`http://localhost:8000`

## Important accuracy note

The strict gate deliberately refuses to pass when the Quran-specific engine reports an error or cannot analyze the recording. This is safer than accepting a normal browser speech-to-text transcript.

It is not a 100% religious/legal guarantee of tajweed correctness. It must be validated against real recordings and a qualified Quran teacher before claiming that level of accuracy.

## Next development stage

- Map each predicted phoneme to exact Uthmani character + haraka.
- Show the exact error: fatḥah/kasrah/ḍammah, shaddah, sukūn, madd, etc.
- Add tajweed rule explanations.
- Add 2 attempts and automatic Sheikh correction.
- Expand from Faatixa to all surahs.
