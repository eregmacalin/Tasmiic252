from pathlib import Path
import tempfile, subprocess, os

import numpy as np
import soundfile as sf
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# Quran-specific engine:
# pip install quran-muaalem
from quran_transcript import Aya, quran_phonetizer, MoshafAttributes, explain_error
from quran_muaalem import Muaalem

BASE = Path(__file__).resolve().parent
app = FastAPI(title="Tasmee Faatixa Strict")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL = None

def get_model():
    global MODEL
    if MODEL is None:
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        MODEL = Muaalem(device=device)
    return MODEL

def convert_to_16k_mono(src: str, dst: str):
    cmd = [
        "ffmpeg","-y","-i",src,
        "-ac","1","-ar","16000","-vn",
        "-f","wav",dst
    ]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError("ffmpeg ayaa diiday audio-ga: " + p.stderr[-500:])

def make_reference(surah: int, ayah: int):
    # Hafs 'an Asim. The reference contains Tajweed-aware phonemes.
    text = Aya(surah, ayah).get().uthmani
    moshaf = MoshafAttributes(
        rewaya="hafs",
        madd_monfasel_len=4,
        madd_mottasel_len=4,
        madd_mottasel_waqf=4,
        madd_aared_len=4,
    )
    return text, quran_phonetizer(text, moshaf, remove_spaces=True)

def error_to_json(err, ref_text, predicted):
    rule = None
    if getattr(err, "ref_tajweed_rules", None):
        rule = ", ".join(str(x.name.en) for x in err.ref_tajweed_rules)
    return {
        "type": getattr(err, "error_type", "unknown"),
        "speech_error": getattr(err, "speech_error_type", "unknown"),
        "position": str(getattr(err, "uthmani_pos", "")),
        "expected": getattr(err, "expected_ph", ""),
        "predicted": getattr(err, "preditected_ph", ""),
        "rule": rule,
        "expected_len": getattr(err, "expected_len", None),
        "predicted_len": getattr(err, "predicted_len", None),
    }

@app.get("/health")
def health():
    return {"ok": True, "service": "tasmee-fatiha-strict"}

@app.get("/")
def home():
    return FileResponse(BASE / "index.html")

@app.post("/analyze")
async def analyze(
    audio: UploadFile = File(...),
    surah: int = Form(1),
    ayah: int = Form(...),
    reciter: str = Form("Alafasy_128kbps"),
):
    if surah != 1 or ayah < 1 or ayah > 7:
        return JSONResponse({"error":"Prototype-kan wuxuu taageeraa Suuratul-Faatixa oo keliya."}, status_code=400)

    src = None; wav = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
            f.write(await audio.read()); src = f.name
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            wav = f.name
        convert_to_16k_mono(src, wav)
        wave, sr = sf.read(wav, dtype="float32")
        if wave.ndim > 1: wave = wave[:,0]
        if sr != 16000: raise RuntimeError(f"Audio sample rate waa {sr}, waa inuu noqdaa 16000.")

        ref_text, ref = make_reference(surah, ayah)
        model = get_model()
        out = model([wave], [ref], sampling_rate=16000)[0]
        predicted = out.phonemes.text

        errors = explain_error(
            uthmani_text=ref_text,
            ref_ph_text=ref.phonemes,
            predicted_ph_text=predicted,
            mappings=ref.mappings,
        )
        errors_json = [error_to_json(e, ref_text, predicted) for e in errors]

        # Strict gate:
        # No automatic pass when the model reports ANY phoneme/tashkeel/tajweed error.
        # Also reject empty/obviously short predictions.
        nonempty = bool(predicted.strip())
        accepted = nonempty and len(errors_json) == 0

        # For a first prototype, expose expected/predicted phoneme sequences.
        # A later UI pass can map every token to a Uthmani character using ref.mappings.
        phonemes = []
        ref_ph = ref.phonemes
        n = min(len(ref_ph), len(predicted))
        for i in range(n):
            phonemes.append({
                "expected": ref_ph[i],
                "predicted": predicted[i],
                "ok": ref_ph[i] == predicted[i]
            })

        audio_url = f"https://everyayah.com/data/{reciter}/{surah:03d}{ayah:03d}.mp3"
        return {
            "accepted": accepted,
            "summary": "Aayadda waxaa la xaqiijiyey phoneme/tajweed reference-ka." if accepted
                       else f"{len(errors_json)} khalad ayaa la helay; aayadda lama gudbinayo.",
            "errors": errors_json,
            "phonemes": phonemes,
            "reference_phonemes": ref_ph,
            "predicted_phonemes": predicted,
            "correction_audio": audio_url,
        }
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        for p in (src, wav):
            if p:
                try: os.unlink(p)
                except OSError: pass
